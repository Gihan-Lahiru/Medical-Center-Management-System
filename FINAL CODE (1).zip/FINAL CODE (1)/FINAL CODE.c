#include <stdio.h>
#include <windows.h>
#include<string.h>
#include<conio.h>

void mainpage();
void listoffer();
void chooseSpecification();
void selectCategory();
void doctorlistCardiologists();
void answer01();
void bill01();
void choiceFinal01();
void test();
void mainCheckup();
void service();
void ContactDetails();
void loadinganimation();

int main() {

    system("COLOR F0");
    mainpage();
    listoffer();

   return 0;
}

void mainpage() {

    int i;

    char header[100] = "\n\n\t\t\t\t\t\t\t\t*===================*\n";
    char middle[100] = "\t\t\t\t\t\t\t\t   WELCOME TO THE\n \t\t\t\t\t\t\t\t       SUWAYA\n  \t\t\t\t\t\t\t\t   MEDICAL CENTER \n";
    char forter[50] = "\t\t\t\t\t\t\t\t*===================*\n\n";

    for (i = 0; i < strlen(header); i++) { //i<character gana venknma type vevii yanava
        printf("%c", header[i]);
        Sleep(13);  // Sleep for 10 milliseconds
    }
    for (i = 0; i < strlen(middle); i++) {
        printf("%c", middle[i]);
        Sleep(35);
    }
    for (i = 0; i < strlen(forter); i++) {
        printf("%c", forter[i]);
        Sleep(13);
    }
    printf("Exceeding patient expectations by the advancement of quality medical services and setting  the standard in the new century for health, healing & comfort\"   The school aims to train and develop young, talented individuals for future nursing positions within the Group. It focuses on building and enhancing the    skills, attitudes and behaviours that are essential for the professional growth and development of nursing professionals at the SUWAYA Group of Hospitals.\n\n");
}

void listoffer(){

    printf("\n Welcome,We Are Offering Below Services For You.\n Please Choose What you Want to...\n\n\n");
    printf("   [ 01 ]  CHANNEL A DOCTOR\n\n");
    printf("   [ 02 ]  TESTS\n\n");
    printf("   [ 03 ]  MEDICAL CHECKUP\n\n");
    printf("   [ 04 ]  OUR SERVICES\n\n");
    printf("   [ 05 ]  CONTACT US\n\n");

    int num;
printf(" Enter Your Requirement Code: ");

scanf("%d",&num);


     system("cls");
switch(num){
case 1:
     chooseSpecification();
     selectCategory();
    break;
case 2:
    test();
    break;
case 3:
    mainCheckup();
    firstCheckup();
     break;
case 4:
    service();
     break;
case 5:
    ContactDetails();
     break;
default:
    printf("You Entered Wrong Number.Please Enter Correct Number\n");
    listoffer();
     break;

}
}

void chooseSpecification(){



    printf("\nChoose An Section For Chanelling\n\n\n");
    printf("   [ 01 ]  Cardiologists (Heart specialists)\n\n");
    printf("   [ 02 ]  Neurologists (Nervous system specialists)\n\n");
    printf("   [ 03 ]  Nephrologists (Kidney specialists)\n\n");
    printf("   [ 04 ]  Pulmonologists (Respiratory system specialists)\n\n\n\n");
    int selection;
    printf("Enter Choice Go Forward Press '1'/'2'/'3'/'4':\n\n");
    printf("Enter Choice Go Backword Press'0': ");
    scanf("%d",&selection);

    if (selection == 1){
        doctorlistCardiologists();
        }
    else if (selection == 2){
        doctorlistNeurologists();
        }
    else if (selection == 3){
        doctorlistNephrologists();
        }
    else if (selection == 4){
        doctorlistPulmonologists();
    }
    else if(selection == 0 ){
       system("cls");
        listoffer();
    }
    else{
        printf("wrong ");
    }
}

void selectCategory(){

int choice;
printf("\nEnter code to continue\n");
scanf("%d",&choice);

switch (choice){
case 1:
    doctorlistCardiologists();
    break;
case 2:
    doctorlistNeurologists();
    break;
case 3:
    doctorlistNephrologists();
    break;
case 4:
    doctorlistPulmonologists();
    break;
default:
    printf("Enter Valid a Number\n");
}
}

void doctorlistCardiologists(){
    system ("cls");
    printf("\nChoose An Doctor For Chanelling\n\n");
    printf("   [ 01 ] Dr.Kasun Lakmal priyadarshana\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(Cantab),FESC,FRCP(Glasgow)\t\t(Monday 6.00 p.m.- 9.00 p.m.)\n\n");
    printf("   [ 02 ] Dr.Imsantha Herath\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(UK),FESC,FRCP(UOC)\t\t\t(Thursday 11.00 a.m.- 6.00 a.m.)\n\n");
    printf("   [ 03 ] Dr.Chandana Kumara \n\t(MBBS MRCP()UK,PhD(AUS)\t\t\t\t\t\t(Thursday 3.00 p.m.- 7.00 p.m.)\n\n");

    int selection;
    printf("Enter Choice Go Forward Press '1'/'2'/'3':\n\n");
    printf("Enter Choice Go Backword Press'0': ");
    scanf("%d",&selection);

    if (selection == 1){
        CardiologistsDoc01();
        }
    else if (selection == 2){
        CardiologistsDoc02();
        }
    else if (selection == 3){
        CardiologistsDoc03();
        }
    else if(selection == 0 ){
       system("cls");
        chooseSpecification();
    }
    else{
        printf("You Entered Wrong Number.Please Enter Correct Number\n");
        doctorlistCardiologists();
    }
}
void CardiologistsDoc01(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Kasun Lakmal priyadarshana?\n\n");
    answer01();
}
void CardiologistsDoc02(){
    system("cls");
    printf("Are You Sure,You Want To Get An Appointment For Dr.Imsantha Herath?\n\n");
    answer01();
}
void CardiologistsDoc03(){
    system("cls");
    printf("Are You Sure,You Want To Get An Appointment For Dr.Chandana Kumara?\n\n");
    answer01();
}


void doctorlistNeurologists(){
    system("cls");
    printf("\nChoose An Doctor For Chanelling\n\n");
    printf("   [ 01 ] Dr.Kasuni hettiarachchi\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(Cantab),FESC,FRCP(Glasgow)\t\t(Monday 6.00 p.m.- 9.00 p.m.)\n\n");
    printf("   [ 02 ] Dr.Imsara laknith\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(UK),FESC,FRCP(UOC)\t\t\t(Thursday 10.00 a.m.- 1.00 p.m.)\n\n");
    printf("   [ 03 ] Dr.Dulara Thashmika \n\t(MBBS MRCP()UK,PhD(AUS)\t\t\t\t\t\t(Thursday 3.00 p.m.- 7.00 p.m.)\n\n");

    int selection;
    printf("Enter Choice Go Forward Press '1'/'2'/'3':\n\n");
    printf("Enter Choice Go Backword Press'0': ");
    scanf("%d",&selection);

    if (selection == 1){
        NeurologistsDoc01();
        }
    else if (selection == 2){
        NeurologistsDoc02();
        }
    else if (selection == 3){
        NeurologistsDoc03();
        }
    else if(selection == 0 ){
       system("cls");
        chooseSpecification();
    }
    else{
    printf("You Entered Wrong Number.Please Enter Correct Number\n");
    doctorlistNeurologists();
    }
}
void NeurologistsDoc01(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Kasuni hettiarachchi?\n\n");
    answer02();
}
void NeurologistsDoc02(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Imsara laknith?\n\n");
    answer02();
}
void NeurologistsDoc03(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Dulara Thashmika?\n\n");
    answer02();
}


void doctorlistNephrologists(){
    system ("cls");
    printf("\nChoose An Doctor For Chanelling\n\n");
    printf("   [ 01 ] Dr.Bawantha Dilshan\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(Cantab),FESC,FRCP(Glasgow)\t\t(Monday 6.00 p.m.- 9.00 p.m.)\n\n");
    printf("   [ 02 ] Dr.Kanchana Herath\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(UK),FESC,FRCP(UOC)\t\t\t(Thursday9.00 a.m.- 10.00 a.m.)\n\n");
    printf("   [ 03 ] Dr.Chandani Kumari \n\t(MBBS MRCP()UK,PhD(AUS)\t\t\t\t\t\t(Thursday 2.00 p.m.- 7.00 p.m.)\n\n");

 int selection;
    printf("Enter Choice Go Forward Press '1'/'2'/'3':\n\n");
    printf("Enter Choice Go Backword Press'0': ");
    scanf("%d",&selection);

    if (selection == 1){
        NephrologistsDoc01();
        }
    else if (selection == 2){
        NephrologistsDoc02();
        }
    else if (selection == 3){
        NephrologistsDoc03();
        }
    else if(selection == 0 ){
       system("cls");
        chooseSpecification();
    }
    else{
       printf("You Entered Wrong Number.Please Enter Correct Number\n");
    doctorlistNephrologists();
    }
}
void NephrologistsDoc01(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Bawantha Dilshan?\n\n");
    answer03();
}
void NephrologistsDoc02(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Kanchana Herath?\n\n");
    answer03();
}
void NephrologistsDoc03(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Chandani Kumari?\n\n");
    answer03();
}


void doctorlistPulmonologists(){
    system ("cls");
    printf("\nChoose An Doctor For Chanelling\n\n");
    printf("   [ 01 ] Dr.Kasun Shehara\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(Cantab),FESC,FRCP(Glasgow)\t\t(Monday 6.00 p.m.- 9.00 p.m.)\n\n");
    printf("   [ 02 ] Dr.Lakitha Manawadu\n\t(MD/Ph.D.),MBBS MRCP()UK,PhD(UK),FESC,FRCP(UOC)\t\t\t(Thursday9.00 a.m.- 11.00 a.m.)\n\n");
    printf("   [ 03 ] Dr.Kusum Manthilake \n\t(MBBS MRCP()UK,PhD(AUS)\t\t\t\t\t\t(Thursday 3.00 p.m.- 7.00 p.m.)\n\n");

 int selection;
    printf("Enter Choice Go Forward Press '1'/'2'/'3':\n\n");
    printf("Enter Choice Go Backword Press'0':\n\n ");
    scanf("%d",&selection);

    if (selection == 1){
        PulmonologistsDoc01();
        }
    else if (selection == 2){
        PulmonologistsDoc02();
        }
    else if (selection == 3){
        PulmonologistsDoc03();
        }
    else if(selection == 0 ){
       system("cls");
        chooseSpecification();
    }
    else{
      printf("You Entered Wrong Number.Please Enter Correct Number\n");
      doctorlistPulmonologists();
    }
}
void PulmonologistsDoc01(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Kasun Shehara?\n\n");
    answer04();
}
void PulmonologistsDoc02(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Lakitha Manawadu?\n\n");
    answer04();
}
void PulmonologistsDoc03(){
    system("cls");
    printf("\nAre You Sure,You Want To Get An Appointment For Dr.Kusum Manthilake?\n\n");
    answer04();
}

void answer01(){
char answer[3];

printf("Enter Choice Go Forward Press:('Y'/'y')\n\nEnter Choice Go Backword Press:('N'/'y')");
scanf(" %c",&answer[0]);
if(answer[0]=='Y'|| answer[0] =='y'){

    bill01();
    choiceFinal01();
}
else if(answer[0]=='N'||answer[0] =='n'){

   //system("cls");
    doctorlistCardiologists();

}
else{
    printf("invalid input");
}

}
void answer02(){
char answer[3];

printf("\nEnter Choice Go Forward Press:('Y'/'y')\n\nEnter Choice Go Backword Press:('N'/'n') ");
scanf(" %c",&answer[0]);
if(answer[0]=='Y'|| answer[0] =='y'){
    printf("okkk");
    bill02();
    choiceFinal02();


}
else if(answer[0]=='N'||answer[0] =='n'){
    printf("nooo");
  //  system("cls");
    doctorlistNeurologists();

}
else{
    printf("invalid input");
}

}
void answer03(){
char answer[3];

printf("\nEnter Choice Go Forward Press:('Y'/'y')\n\nEnter Choice Go Backword Press:('N'/'n') ");
scanf(" %c",&answer[0]);
if(answer[0]=='Y'|| answer[0] =='y'){

    bill03();
    choiceFinal03();

}
else if(answer[0]=='N'||answer[0] =='n'){

    //system("cls");
    doctorlistNephrologists();

}
else{
    printf("invalid input");
}

}
void answer04(){
char answer[3];

printf("\nEnter Choice Go Forward Press:('Y'/'y')\n\nEnter Choice Go Backword Press:('N'/'n') ");
scanf(" %c",&answer[0]);
if(answer[0]=='Y'|| answer[0] =='y'){

    bill04();
    choiceFinal04();
}
else if(answer[0]=='N'||answer[0] =='n'){

    //system("cls");
    doctorlistPulmonologists();

}
else{
    printf("invalid input");
}

}

void bill01(){
    system("cls");
    loadinganimation();
    printf("\n\nYour Appointment Has Proceed\n\n");
    printf("\t\t\t==============================================\n");
    printf("\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t==============================================\n\n\t\t\tYour Billing No: 01\n\n\n\n\t\t\tDoctor Charge:                     RS.2500 /=\n\n\t\t\tHospital Charge:                   RS.1000 /=\n\n\n");
    printf("\t\t\t                                  ------------\n\n");
    printf("\t\t\t                                    RS.3500 /=\n");
    printf("\t\t\t                                  ============\n\n\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t==============================================\n");
}
void bill02(){
    system("cls");
    loadinganimation();
    printf("\n\nYour Appointment Has Proceed\n\n");
    printf("\t\t\t==============================================\n");
    printf("\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t==============================================\n\n\t\t\tYour Billing No: 01\n\n\n\n\t\t\tDoctor Charge:                     RS.3500 /=\n\n\t\t\tHospital Charge:                   RS.1000 /=\n\n\n");
    printf("\t\t\t                                  ------------\n\n");
    printf("\t\t\t                                    RS.4500 /=\n");
    printf("\t\t\t                                  ============\n\n\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t==============================================\n");
    ;
}
void bill03(){
    system("cls");
    loadinganimation();
    printf("\n\nYour Appointment Has Proceed\n\n");
    printf("\t\t\t==============================================\n");
    printf("\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t==============================================\n\n\t\t\tYour Billing No: 01\n\n\n\n\t\t\tDoctor Charge:                     RS.2500 /=\n\n\t\t\tHospital Charge:                   RS.1000 /=\n\n\n");
    printf("\t\t\t                                  ------------\n\n");
    printf("\t\t\t                                    RS.3500 /=\n");
    printf("\t\t\t                                  ============\n\n\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t==============================================\n");
}
void bill04(){
    system("cls");
    loadinganimation();
    printf("\n\nYour Appointment Has Proceed\n\n");
    printf("\t\t\t==============================================\n");
    printf("\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t==============================================\n\n\t\t\tYour Billing No: 01\n\n\n\n\t\t\tDoctor Charge:                     RS.3500 /=\n\n\t\t\tHospital Charge:                   RS.1000 /=\n\n\n");
    printf("\t\t\t                                  ------------\n\n");
    printf("\t\t\t                                    RS.4500 /=\n");
    printf("\t\t\t                                  ============\n\n\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t==============================================\n");

}

void choiceFinal01(){
int  answer;
  printf("Enter Choice Go Backword Press '1':\n\nEnter Choice Go Main Menu Press '2':\n\nExit Chanelling Press'0' ");
  scanf(" %d",&answer);
if(answer==1){
    system("cls");
    doctorlistCardiologists();
}
else if(answer==2){
    system("cls");
    listoffer();
}
else if(answer==0){

    system("cls");
    exit(0);
}
else{
    printf("invalid input");
}
    exit(0);
}
void choiceFinal02(){
int  answer;
  printf("Enter Choice Go Backword Press '1':\n\nEnter Choice Go Main Menu Press '2':\n\nExit Chanelling Press'0' ");
  scanf(" %d",&answer);
if(answer==1){
    system("cls");
    doctorlistNeurologists();

}
else if(answer==2){
    system("cls");
    listoffer();

}
else if(answer==0){

    system("cls");
    exit(0);
}
else{
    printf("invalid input");
}
    exit(0);
}
void choiceFinal03(){
int  answer;
  printf("Enter Choice Go Backword Press '1':\n\nEnter Choice Go Main Menu Press '2':\n\nExit Chanelling Press'0' ");
  scanf(" %d",&answer);
if(answer==1){
    system("cls");
    doctorlistNephrologists();

}
else if(answer==2){
    system("cls");
    listoffer();

}
else if(answer==0){

    system("cls");
    exit(0);
}
else{
    printf("invalid input");
}
    exit(0);
}
void choiceFinal04(){




int  answer;
  printf("Enter Choice Go Backword Press '1':\n\nEnter Choice Go Main Menu Press '2':\n\nExit Chanelling Press'0' ");
  scanf(" %d",&answer);
if(answer==1){
    system("cls");
    doctorlistPulmonologists();

}
else if(answer==2){

    system("cls");
    listoffer();

}
else if(answer==0){

    system("cls");
    exit(0);
}
else{
    printf("invalid input");
}
    exit(0);
}

void test(){
    printf("\n\n\t\t\t\t\t========================================");
    printf("\n \t\t\t\t\t\t\M E D I C A L  T E S T S \n");
    printf("\t\t\t\t\t\========================================");

    int choice;
    printf("\n\n \t\t Medical tests can help detect a condition, determine a diagnosis,plan treatment,\n");
    printf(" \t\t     check to see if treatment is working,r monitor the condition over time.\n");
    printf("\t\t\t A doctor may order these tests as part of a routine checkup,\n");
    printf("\t\t     to check for certain diseases and disorders, or to monitor your health.\n");
    printf("\n\n \t\t\twe offer below medical tests for you!:  \n\n");
    printf("\t\t\t\t\t\t[01].Blood Test - Rs.500/=\n");
    printf("\t \t\t\t\t\t[02].Urine Test - Rs.450/=\n");
    printf("\t \t\t\t\t\t[03].X-ray\t- Rs.800/=\n");
    printf("\t \t\t\t\t\t[04].MRI\t- Rs.25000/=\n");
    printf("\t\t\t\t\t\t[05].ECG\t- Rs.550/=\n\n");

    int i;
    int total = 0;
    int choices;
    int blood=500;
    int urine=450;
    int xray=800;
    int mri=25000;
    int ecg=550;
    char x[5][100];

    printf("\t\t Enter your choice 1 to 5,(If you don't need one,press 0 for it).\n");

    printf("\t\t You can choose 5 test per time:  \n\n\t\t *Press '6' for Previous Page:\n ");


    for (i = 0; i < 5; i++) {
        printf("\t\t\t\t\t");
             scanf("%d",&choices);
             if(choices<0 || choices>6 ){
                printf("Invalid");

             }
             else{


        switch (choices) {
            case 1:
                strcpy(x[i],"\t\t\t\tBlood Test                  = 500");
                total += 500;
                break;
            case 2:
                strcpy(x[i],"\t\t\t\tUrine Test                  = 450");
                total += 450;
                break;
            case 3:
                strcpy(x[i],"\t\t\t\tX-ray                       = 800");
                total += 800;
                break;
            case 4:
                strcpy(x[i],"\t\t\t\tMRI                        = 2500");
                total += 25000;
                break;
            case 5:
                strcpy(x[i],"\t\t\t\tECG                         = 550");
                total += 550;
                break;
            case 6:
                system("cls");
                listoffer();
                break;

        }
        }}


    system ("cls");
    loadinganimation();
    printf("\t\t\t========================================================\n");
    printf("\t\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t========================================================\n\n\t\t\t");
    printf("\t\t\t                                  \n\n");
    for(int y=0;y<5;y++){
        printf("%s\n",x[y]);
    }
    printf("              \t                       \t\t\t-----------\n");
    printf("");
    printf("\t\t\t\tYour Total fee is:\t \Rs.%d/=\n ",total);

    printf("                            \t    \t \t\t===========\n");
    printf("\t\t\t                                  \n\n`\n\t\t\t\t\t       = THANK YOU =\n\n");
    printf("\t\t\t========================================================\n");
        printf("\n\n\t Press '1' for the main menu\n\t Press '0' For Exit :");
    int num;
    scanf("%d",&num);
    if(num==1){
            system("cls");
           listoffer();
    }
    else (num==0);{
             system("cls");
       exit(0);
    }}

void mainCheckup(){

    int i;
    char header[100] = "\n\n\t\t\t\t\t\t\t*=========================================*\n";
    char middle[100] = "\t\t\t\t\t\t\t\t   Health Check Packages\n";
    char forter[50] = "\t\t\t\t\t\t\t*=========================================*\n\n\n\n";

    for (i = 0; i < strlen(header); i++) {
        printf("%c", header[i]);
        Sleep(10);  // Sleep for 10 milliseconds
    }

    for (i = 0; i < strlen(middle); i++) {
        printf("%c", middle[i]);
        Sleep(40);
    }

    for (i = 0; i < strlen(forter); i++) {
        printf("%c", forter[i]);
        Sleep(10);
    }
    }
void firstCheckup(){


    printf("\n\n\t\t(1) Starter Health Check Package\n\n");
    printf("\t\t(2) Essential Health Check Package\n\n");
    printf("\t\t(3) Essential Plus Health Check Package\n\n");
    printf("\t\t(4) Professional Health Check Package\n\n");
    printf("\t\t(5) Premium Male Health Check Package\n\n\n");


     int num;
     printf("\t\tSelect a package(1-5)\n\n");
     printf("\t\tPress '6' for Main Menu\n\n\t\tEnter Your Package:");
     scanf("%d",&num);
     system("cls");

    switch (num){
    case 1:
          HealthCheckup1();
          break;
    case 2:
        HealthCheckup2();
          break;
    case 3:
        HealthCheckup3();
          break;
    case 4:
        HealthCheckup4();
          break;
    case 5:
        HealthCheckup5();
          break;
    case 6:
         listoffer();
          break;
    default:
         printf("\t\tEnter Correct Number");
         //system("cls");
         mainCheckup();
         firstCheckup();
    }
    }
void HealthCheckup1(){

      system("cls");
      int num,num1;
      float num2=6450.00;
      printf("\t(1) Starter Health Check Package\n\n");
      printf("\tThis includes \n\n\t*Full Blood Count (General Body Condition)\n\t*Fasting Blood Sugar (Glucose Levels)\n\t*Cholesterol (Cardiac Health)\n\t*Triglycerides (Cardiac Health)\n\t*Creatinine & eGFR (Kidney & Renal Health)\n\t*Gamma GT (Liver Health)\n\t*SGPT (Liver Health)\n\t*Urine Full Report (General Body Condition)\n\t*ECG (Cardiac Health)\n\t*Full Medical Report\n\n\n");
      printf("\tPrice Rs.6,450.00\n\n");
      printf("\tFor select this package press 1\n\tFor previous page press 2 : ");
      scanf("%d",&num);
      system("cls");
      if (num==1){
        printf("You selected The Starter Package.\n");
       system("cls");

       loadinganimation();

    printf("\n\nYour Health Check Package Has Proceed\n\n");
    printf("\t\t\t========================================================\n");
    printf("\t\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t========================================================\n\n\t\t\t");
    printf("\t\t\t                                  \n\n");
    printf("\t\t\tYour Package fee is ");
    printf("                              %.2f\n",num2);
    printf("\t\t\tVat 18%% ");
    printf("\t                                  1161.00\n\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\tYour Total fee is ");
    printf("                                7611.00\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\t                                  \n\n`\n\t\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t========================================================\n");
    printf("\n\n\tPress '1' for the previous page\n\tpress '2' for main menu \n\tpress'0' For Exit :");
    scanf("%d",&num1);
    if(num1==1){
            system("cls");
            printf("\t\tHealth Check Packages");
           firstCheckup();

    }
    else if(num1==2){
            system("cls");
       listoffer();
    }
    else if(num1==0){
            system("cls");
       exit(0);
    }

      }
      else

        firstCheckup();
        printf("\t\tHealth Check Packages");

      }
void HealthCheckup2(){
      system("cls");
      int num,num1;
      float num2=10450.00;
      printf("\t(2) Essential Health Check Package\n\n");
      printf("This includes \n\t*Full Blood Count (General Body Condition)\n");
      printf("\t*Fasting Blood Sugar (Glucose Levels)\n\t*Lipid Profile (Cardiac Health)\n\t*Creatinine & eGFR (Kidney & Renal Health)\n\t*Gamma GT (Liver Health)\n\t*SGPT (Liver Health)\n\t*SGOT (Liver Health)\n\t*TSH (3rd Generation) (Thyroid Profile)\n");
      printf("\t*Urine Full Report (General Body Condition)\n\t*Stool Occult Blood (Bleeding in Lower Intestines)\n\t*ECG (Cardiac Health)\n\t*Full Medical Report\n");
       printf("Price Rs.10,450.00\n\n") ;
      printf("For select this package press 1\nFor previous page press 2 : ");
      scanf("%d",&num);

      system("cls");
      if (num==1){
        printf("You selected The  Essential Package.\n");
         system("cls");

         loadinganimation();

     printf("\n\nYour Health Check Package Has Proceed\n\n");
    printf("\t\t\t========================================================\n");
    printf("\t\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t========================================================\n\n\t\t\t");
    printf("\t\t\t                                  \n\n");
    printf("\t\t\tYour Package fee is ");
    printf("                             %.2f\n",num2);
    printf("\t\t\tVat 18%% ");
    printf("\t                                  1881.00\n\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\tYour Total fee is ");
    printf("                               12333.00\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\t                                  \n\n`\n\t\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t========================================================\n");
   printf("\n\n\Press '1' for the previous page\npress '2' for main menu \npress'0' For Exit :");
    scanf("%d",&num1);

    if(num1==1){
            system("cls");
            printf("\t\tHealth Check Packages");
           firstCheckup();

    }
    else if(num1==2){
            system("cls");
       listoffer();
    }
    else if(num1==0){
            system("cls");
       exit(0);
    }

      }

      else

        firstCheckup();
        printf("\t\tHealth Check Packages");

      }
void HealthCheckup3(){
        system("cls");
      int num,num1;
      float num2=49000.00;
      printf("\t(3) Essential Plus Health Check Package\n\n");
      printf("This includes \n\t*Full Blood Count (General Body Condition)\n");
      printf("\t*Fasting Blood Sugar (Glucose Levels)\n\t*HbA1C (Diabetes � Glucose Levels)\n\t*Adiponectin (Early Detection of Diabetes)\n\t*Lipid Profile (Cardiac Health)\n\t*Renal Profile (Overall Kidney Health)\n\t*Liver Profile (Liver function & Health)\n\t*Thyroid Profile (Overall Thyroid Condition)\n");
      printf("\t*PSA (Prostate Cancer Detection � Males over 50 years)\n\t*ESR (Infections/Inflammation)\n\t*hsCRP (Inflammation/Identifying Heart Disease)\n\t*Urine Full Report (General Body Condition)\n\t*Micro Albumin (Kidney Health)\n\t*Stool Occult Blood (Bleeding in Lower Intestines\n)");
      printf("\t*Chest X-ray (Lung Condition) � Once every 3-5 years\n\t*Ultrasound Scan (Abdominal & Pelvis Investigation)\n\t*ECG (Cardiac Health)\n\t*Echocardiogram (Identifying Cardiovascular Disease)\n\t*TMT � Stress Test (Cardiovascular Function)\n\t*Eye Assessment\n\t*Full Medical Report\n");
      printf("Price Rs.49,000.00\n");
        printf("For select this package press 1\nFor previous page press 2 : ");
      scanf("%d",&num);
      system("cls");
      if (num==1){
        printf("You selected The Starter Package.\n");
         system("cls");

         loadinganimation();

     printf("\n\nYour Health Check Package Has Proceed\n\n");
    printf("\t\t\t========================================================\n");
    printf("\t\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t========================================================\n\n\t\t\t");
    printf("\t\t\t                                  \n\n");
    printf("\t\t\tYour Package fee is ");
    printf("                             %.2f\n",num2);
    printf("\t\t\tVat 18%% ");
    printf("\t                                  8820.00\n\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\tYour Total fee is ");
    printf("                               57820.00\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\t                                  \n\n`\n\t\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t========================================================\n");
   printf("\n\n\Press '1' for the previous page\npress '2' for main menu \npress'0' For Exit :");
    scanf("%d",&num1);
   if(num1==1){
            system("cls");
            printf("\t\tHealth Check Packages");
           firstCheckup();

    }
    else if(num1==2){
            system("cls");
       listoffer();
    }
    else if(num1==0){
            system("cls");
       exit(0);
    }
}


      else

        firstCheckup();
        printf("\t\tHealth Check Packages");

      }
void HealthCheckup4(){
      system("cls");
      int num,num1;
      float num2=27900.00;
      printf("\t(4) Professional Health Check Package\n\n");
      printf("This includes \n\t*Full Blood Count (General Body Condition)\n");
      printf("\t*Fasting Blood Sugar (Glucose Levels)\n\t*HbA1C (Diabetes - Glucose Levels)\n\t*HealthCheckup3();\n\t*Creatinine & eGFR (Kidney & Renal Health)\n\t*Liver Profile (Liver Function & Health)\n\t*TSH (3rd Generation) (Thyroid Profile)\n\t*PSA (Prostate Cancer Detection � Males Over 50 Years)\n");
      printf("\t*hsCRP (Inflammation/Identifying Heart Disease)\n\t*Urine Full Report (General Body Condition)\n\t*Micro Albumin (Kidney Health)\n\t*Stool Occult Blood (Bleeding in Lower Intestines)\n\t*Ultrasound Scan (Abdominal & Pelvis Investigation)\n\t*ECG (Cardiac Health)\n)");
      printf("\t*Full Medical Report\n");
      printf("Price Rs.27,900.00\n");
        printf("For select this package press 1\nFor previous page press 2 : ");
      scanf("%d",&num);
      system("cls");
      if (num==1){
        printf("You selected The Starter Package.\n");
         system("cls");

         loadinganimation();

     printf("\n\nYour Health Check Package Has Proceed\n\n");
    printf("\t\t\t========================================================\n");
    printf("\t\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t========================================================\n\n\t\t\t");
    printf("\t\t\t                                  \n\n");
    printf("\t\t\tYour Package fee is ");
    printf("                             %.2f\n",num2);
    printf("\t\t\tVat 18%% ");
    printf("\t                                  5022.00\n\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\tYour Total fee is ");
    printf("                               32922.00\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\t                                  \n\n`\n\t\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t========================================================\n");
    printf("\n\n\Press '1' for the previous page\npress '2' for main menu \npress'0' For Exit :");
    scanf("%d",&num1);
   if(num1==1){
            system("cls");
            printf("\t\tHealth Check Packages");
           firstCheckup();

    }
    else if(num1==2){
            system("cls");
       listoffer();
    }
    else if(num1==0){
            system("cls");
       exit(0);
    }
 }


      else

        firstCheckup();
        printf("\t\tHealth Check Packages");


      }
void HealthCheckup5(){
      system("cls");
      int num,num1;
      float num2=89900.00;
      printf("\t(5) Essential Plus Health Check Package\n\n");
      printf("This includes \n\t*Full Blood Count (General Body Condition)\n");
      printf("\t*Fasting Blood Sugar (Glucose Levels)\n\t*HbA1C (Diabetes � Glucose Levels)\n\t*Adiponectin (Early Detection of Diabetes)\n\t*Lipid Profile (Cardiac Health)\n\t*Renal Profile (Overall Kidney Health)\n\t*Liver Profile (Liver function & Health)\n\t*Thyroid Profile (Overall Thyroid Condition)\n");
      printf("\t*PSA (Prostate Cancer Detection � Males over 50 years)\n\t*ESR (Infections/Inflammation)\n\t*hsCRP (Inflammation/Identifying Heart Disease)\n\t*Urine Full Report (General Body Condition)\n\t*Micro Albumin (Kidney Health)\n\t*Stool Occult Blood (Bleeding in Lower Intestines\n)");
      printf("\t*Chest X-ray (Lung Condition) � Once every 3-5 years\n\t*Ultrasound Scan (Abdominal & Pelvis Investigation)\n\t*ECG (Cardiac Health)\n\t*Echocardiogram (Identifying Cardiovascular Disease)\n\t*TMT � Stress Test (Cardiovascular Function)\n\t*Eye Assessment\n\t*Full Medical Report\n");
      printf("\t*Thyroid Profile (Overall Thyroid Condition)\n\t*Vitamin D Assay (General Body Condition/Bone Health)\n\t*CEA (Colon Cancer Screening)\n\t*CEA (Colon Cancer Screening)\n\t*CEA (Colon Cancer Screening)\n\t*Micro Albumin (Kidney Health)\n\t*TMT - Stress Test (Cardiovascular Function)\n\t*Lung Function Test\n");
      printf("Price Rs.89,900.00\n");
        printf("For select this package press 1\nFor previous page press 2 : ");
      scanf("%d",&num);
      system("cls");
      if (num==1){
        printf("You selected The Starter Package.\n");
         system("cls");

    loadinganimation();

     printf("\n\n\tYour Health Check Package Has Proceed\n\n");
    printf("\t\t\t========================================================\n");
    printf("\t\t\t\t          SUWAYA MEDICAL CENTER               \n");
    printf("\t\t\t========================================================\n\n\t\t\t");
    printf("\t\t\t                                  \n\n");
    printf("\t\t\tYour Package fee is ");
    printf("                             %.2f\n",num2);
    printf("\t\t\tVat 18%% ");
    printf("\t                                 16182.00\n\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\tYour Total fee is ");
    printf("                              106082.00\n");
    printf("\t\t\t\t\t                               ----------\n");
    printf("\t\t\t                                  \n\n`\n\t\t\t\t\t\t= THANK YOU =\n\n");
    printf("\t\t\t========================================================\n");
    printf("\n\n\Press '1' for the previous page\npress '2' for main menu \npress'0' For Exit :");
    scanf("%d",&num1);
   if(num1==1){
            system("cls");
            printf("\t\tHealth Check Packages");
           firstCheckup();

    }
    else if(num1==2){
            system("cls");
       listoffer();
    }
    else if(num1==0){

       exit(0);
    }

      }
      else

        firstCheckup();
        printf("\t\tHealth Check Packages");


      }

void service(){

printf("\n\n\t\t\t\t\t\t\t      === MEDICAL & SURGICAL SERVICES ===\n\n Suwaya Hospitals has revolutionized the Sri Lankan healthcare industry. For over a decade we have played a critical role in the nation�s strategy to provide world-class medical care whilst balancing the equation of affordability and accessibility for all Sri Lankans. For us service excellence is dynamic, which is why we constantly seek to enhance our service delivery in a bid to provide our customers with world-care healthcare experiences.\n");
printf("At Lanka Hospitals, we provide both clinical and non-clinical care, always striving for excellence through a meticulous drive for quality and continuous improvement. We provide 280-bed multi-speciality tertiary care medical services located in seven acres of beautifully landscaped garden. Lanka Hospitals provides state of the art features that are complemented by cutting edge technology and is staffed by a well-experienced and trained team. We provide a complete range of the latest diagnostic and high-end medical technology\n\n");
printf("\t\t\t\t\t\t\t\t  === DIAGNOSTIC FACILITIES ===\n\nAll types of diagnostic blood tests Blood film examination Bone marrow aspirations and biopsies Lymph node biopsy Ultra-Sound, CT & MRI Scanning Treatment FacilitiesA dedicated in-patient facility only for patients with Haematological disorders for chemotherapy and supportive care Haematology Day Unit (HDU) for day chemotherapy/ out-patient chemotherapy/ patient monitoring and other procedures Out-patient consultation service � OPD 6 Ground Floor Transfusion programme for thalassemia patients Treatment OptionsChemotherapy for all types of blood cancers Bone marrow transplants\n\n");
printf("\t\t\t\t\t\t\t\t      === EYE CLINIC ===\n\nWith a dedicated team of local and foreign consultant ophthalmologists, highly trained nurses and access to the most up-to-date technology, our Eye Clinic is the only private eye clinic in Sri Lanka to offer a complete range of services in one central location.Both foreign and local, internationally trained ophthalmologists, supported by and the very latest technologies are on hand.\n\n");
printf("\t\t\t\t\t\t\t\t     === NEUROLOGY CENTRE ===\n\nOur Neurology Department is unique in that we are the only department in the private healthcare sector in Sri Lanka to offer the services of 3 full-time Neurologists/ Surgeons who are present all day to facilitate cases of emergency. On our team are a number of neuro-electrophysiology technicians to conduct  EEG and EMG tests. Our patients have the convenience of collecting results on the same day the test is conducted. We are also the only hospital in the country to carry out long-term video EEG monitoring.\n\n");
printf("\t\t\t\t\t\t\t\t     === RADIOLOGY SERVICES ===\n\nThrough the use of an array of radiology and imaging services, we aim towards diagnosing diseases where outward symptoms don�t give us the full picture. Our radiological and imaging services include state-of-the-art equipment ranging from MRI, CT, Ultra sound scanning, Digital X-Ray, Digital Dental X ray, Dexa scan and Mammography. Our team of experienced and qualified consultant radiologist and radiographers will make you at ease, assisting you towards the accurate diagnosis. Our advanced MRI scanner .\n\n");
printf("Enter Choice Go Main Menu'1':\nExit '0'");
int answer;
scanf(" %d",&answer);
if(answer==1){
    system("cls");
    listoffer();
}
else if(answer==0){

    system("cls");

    exit(0);
}
else {
    printf("Wrong Input");
}

return 0;
}

void ContactDetails() {
    printf("\n\t===================================================\n");
    printf("\t\t   Contact Us - SUWAYA MEDICAL CENTER\n");
    printf("\t===================================================\n\n");

    printf("   Hospital Name\t:\t\tSUWAYA Medical Center\n");
    printf("   Address\t\t:    \t  \t123, Main Street, Colombo 07\n");
    printf("   Phone\t\t:        \t+94 (011) 123-4567\n");
    printf("   Email\t\t:       \tinfo@suwayamedicalcenter.com\n\n");

    printf("\n   \t\tFor emergencies, please call 119.\n");

    printf("\n\t==============================================\n\n");
    printf("Enter Choice Go Main Menu'1':\nExit '0'");
int answer;
scanf(" %d",&answer);
if(answer==1){
    system("cls");
    listoffer();
   // mainpage();

}
else if(answer==0){
    system("cls");
    exit(0);
}
else {
    printf("Wrong Input");
}

return 0;

}
//animation
void loadinganimation(){

int e;
int numFrames =10;
int delay=60000;

for(e=0; e<numFrames;++e){
    printf("\r\t\t\t\t\tLOADING -");
    fflush(stdout);
    usleep(delay);

    printf("\r\t\t\t\t\tLOADING /");
    fflush(stdout);
    usleep(delay);

    printf("\r\t\t\t\t\tLOADING |");
    fflush(stdout);
    usleep(delay);

    printf("\r\t\t\t\t\tLOADING \\");
    fflush(stdout);
    usleep(delay);
}
system("cls");

}

